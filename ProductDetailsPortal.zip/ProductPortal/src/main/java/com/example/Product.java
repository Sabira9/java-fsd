package com.example;

public class Product {
	private int ID;
	private String pName;
	private float pPrice;
	
	public Product(int iD, String pName, float pPrice) {
		super();
		this.ID = iD;
		this.pName = pName;
		this.pPrice = pPrice;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public float getpPrice() {
		return pPrice;
	}

	public void setpPrice(float pPrice) {
		this.pPrice = pPrice;
	}
	


}
