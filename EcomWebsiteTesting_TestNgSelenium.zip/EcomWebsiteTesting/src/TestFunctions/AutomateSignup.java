package TestFunctions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AutomateSignup {

	WebDriver driver = null;
	@BeforeTest
	public void Config() {
		System.setProperty("webdriver.chrome.driver", "D:\\95\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	@Test
	public void signUp() throws InterruptedException {
				driver.get("https://cupsofmagik.com/account/register");
				
				driver.findElement(By.id("FirstName")).sendKeys("Sabi");
				driver.findElement(By.id("LastName")).sendKeys("Nazar");
				driver.findElement(By.id("Email")).sendKeys("sabi@gmail.com");
				driver.findElement(By.id("CreatePassword")).sendKeys("Sabi@1234");
				
				driver.findElement(By.className("btn")).click();
				Thread.sleep(2000);
				System.out.println("SignUp Successful"); 
				
		  }
	@AfterTest
	public void close() {
		driver.quit();
	}
}
