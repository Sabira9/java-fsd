package TestFunctions;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AddToCart {
	
	WebDriver driver = null;
	@BeforeTest
	public void Config() {
		System.setProperty("webdriver.chrome.driver","D:\\95\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	
	@Test
	public void AddtoCart() {
		driver.get("https://www.amazon.in/");
		WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
		searchBox.sendKeys("oppo a54",Keys.ENTER);
		//searchBox.submit();
		driver.findElement(By.linkText("OnePlus Nord CE 2 5G (Gray Mirror, 8GB RAM, 128GB Storage)")).click();
	    ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
	    driver.switchTo().window(tabs2.get(1));
		driver.findElement(By.id("add-to-cart-button")).click();
		System.out.println("product added to cart successfully"); 
	}
	@AfterTest
	public void close() {
		driver.quit();
	}
}
