package filehandle;

import java.io.IOException;
import java.io.FileReader;
import java.util.Scanner;

public class FileRead {

	public static void main(String[] args) throws IOException{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the file name");
		FileReader file=new FileReader(sc.next());
		if(file!=null)
		{
			System.out.println("file exist");
		}
		int i=0;    
        while((i=file.read())!=-1){    
            System.out.print((char)i);    
           }    
           file.close();    
          
        }    
       }  


