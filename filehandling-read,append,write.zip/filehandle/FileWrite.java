package filehandle;

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
public class FileWrite
{
	public static void main(String[] args) throws IOException
	{
		FileWriter file=new FileWriter("input",true);
		if(file!=null)
		{
			System.out.println("file is created and opened in write mode");
		}
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the content:");
		String fileinput=sc.nextLine();
		file.write(fileinput);
		System.out.println("Writing the content is completed");
		file.close();

	}

}
