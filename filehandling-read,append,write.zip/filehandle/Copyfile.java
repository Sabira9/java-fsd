package filehandle;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;


public class Copyfile {

	public static void main(String[] args) throws IOException
	{	
		Scanner sc=new Scanner(System.in);
		FileInputStream file=new FileInputStream("input");
		System.out.println("enter the name of new file:");
		FileOutputStream file1=new FileOutputStream(sc.next());
		if(file1!=null)
		{
			System.out.println("new file created and opened on write mode");
		}
		
		int i=0;
		while((i=file.read())!=-1)
		{
		file1.write(i);
	    }
      System.out.println("file appended successfully");
		file1.close();
		file.close();

		
}
}