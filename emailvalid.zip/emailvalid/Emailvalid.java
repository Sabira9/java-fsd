package emailvalid;

import java.util.*;


public class Emailvalid {

	public static void main(String[] args) {
		Scanner em=new Scanner(System.in);
		String emailadd;
		int flag=0;
		ArrayList<String> email=new ArrayList<String>();
		email.add("sab@gmail.com");
		email.add("fath@gmail.com");
		email.add("safa@gmail.com");
		System.out.println("Enter the email address:");
		emailadd=em.next();
		for(String val:email)
		{
			if(val.contains(emailadd))
			{
				flag=1; 
				break;
			}
		}
        if(flag==1)
        {
        	System.out.println("Found the emailID-Successfull search");
        }
        else
        {
        	System.out.println("Not Found the emailID-Failed search");
        }
		}
	}


