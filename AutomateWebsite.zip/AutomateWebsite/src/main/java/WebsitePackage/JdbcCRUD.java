package WebsitePackage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class JdbcCRUD {
	public int insert(Employee e) throws ClassNotFoundException, SQLException {
		Connection con=DbUtil.dBConn();
		String sql="insert into Employee values(?,?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1,e.getEmpname());
		ps.setString(2,e.getEmail());
		ps.setString(3,e.getPassword());
		return ps.executeUpdate();
	}
  public boolean check(String email,String password) throws ClassNotFoundException, SQLException {
	Connection con=DbUtil.dBConn();
	Statement st=con.createStatement();
	String sql="Select * from Employee";
	ResultSet rs=st.executeQuery(sql);
	System.out.println(rs);
	boolean re=false;
	while(rs.next())
	{
		if(email.equals(rs.getString(2)) && password.equals(rs.getString(3)))
				{
			re=true;
			break;
				}
	}
	return re;
}
}
