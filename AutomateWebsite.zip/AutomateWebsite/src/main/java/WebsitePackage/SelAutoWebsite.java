package WebsitePackage;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SelAutoWebsite {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\95\\chromedriver.exe");
		WebDriver wd=new ChromeDriver();
		//maximize the screen
		wd.manage().window().maximize();
		
		//Register
		
		wd.manage().timeouts().pageLoadTimeout(2000, TimeUnit.MILLISECONDS);
		wd.get("http://localhost:8083/AutomateWebsite/Register.jsp");
	//	wd.manage().timeouts().implicitlyWait(2000,TimeUnit.MILLISECONDS);
		wd.findElement(By.name("ename")).sendKeys("safa");
		Thread.sleep(2000);
		wd.findElement(By.name("email")).sendKeys("safa@gn");
		wd.findElement(By.name("pass")).sendKeys("safana");
		Thread.sleep(2000);
		wd.findElement(By.name("submit")).submit();
		Thread.sleep(2000);
		
		//Successfull Login
		
		wd.findElement(By.name("email")).sendKeys("safa@gn");
		Thread.sleep(2000);
		wd.findElement(By.name("pass")).sendKeys("safana");
		Thread.sleep(2000);
		wd.findElement(By.name("submit")).submit();
		
		//Unsuccessfull Login
		
		/*wd.findElement(By.name("email")).sendKeys("safa@gn");
		wd.findElement(By.name("pass")).sendKeys("saf");
		Thread.sleep(2000);
		wd.findElement(By.name("submit")).submit();*/
		
		
	}

}
